import { Link } from "react-router-dom"

function Home(){
    return (
        <>
            <h1>Home Componant</h1>

            {/* <a href="/about">about</a> */}  
            {/* isse page reload hoga */}

            {/* ye shi tareeka hai , isse refresh nhi hoga */}
            {/* <Link to='/about'> About Us </Link> */}

        </>
    )
}

export default Home 