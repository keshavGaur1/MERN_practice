function ViewUser(){
    return (
        <>
            <h1>View all Users Componant</h1>
        </>
    )
}

export default ViewUser 