
function HookDemo2(){

    function formHandler (event) {
        event.preventDefault()
        console.log(event);
    }

    return (
        <>
        <h1>hook demo 2 componant   </h1>

        <div align='center'>

            <form method="post" onSubmit={formHandler}>
                <table className="table table-bordered w-50">
                    <tbody>
                        <tr>
                            <td>User Name </td> 
                            <td> <input type="text" name="unm"/> </td>
                        </tr>
                        <tr>
                            <td> Password </td> 
                            <td> <input type="password" name="pwd"/> </td>
                        </tr>
                        <tr>
                            <td colSpan={2}> <input type="submit" name="subBtn"/> </td>
                        </tr>
                    </tbody>
                </table>
            </form>


        </div>
            
        </>
    )
}

export default HookDemo2 
