function AddUser(){
    return (
        <>
            <h1>Add User Componant</h1>
        </>
    )
}

export default AddUser 