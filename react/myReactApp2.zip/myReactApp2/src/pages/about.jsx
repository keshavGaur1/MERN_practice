function About(){
    return (
        <>
            <h1>About Componant</h1>
        </>
    )
}

export default About 